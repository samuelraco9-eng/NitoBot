const {
    default: makeWASocket,
    useMultiFileAuthState
} = require("@whiskeysockets/baileys")

global.modStatus = {}

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState("./auth")
    const sock = makeWASocket({
        printQRInTerminal: true,
        auth: state
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message) return

        const from = msg.key.remoteJid
        const sender = msg.key.participant || msg.key.remoteJid
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || ""

        if (!from.endsWith("@g.us")) return

        const groupMetadata = await sock.groupMetadata(from)
        const admins = groupMetadata.participants
            .filter(p => p.admin)
            .map(p => p.id)

        const isAdmin = admins.includes(sender)

        // help
        if (isAdmin && text.startsWith(".help")) {
            const helpMessage = `
📌 *Comandos del Bot*

⭐ *Gestión*
.kick @usuario - Expulsar del grupo
.promote @usuario - Hacer admin
.demote @usuario - Quitar admin

⭐ *Mods*
.activo - Marcar mod activo
.inactivo - Marcar mod inactivo
.mods - Ver mods activos (todos pueden usarlo)

⭐ *Mensajes*
.resaltar - Resaltar un mensaje (respuesta)
.ping - Ver si el bot está activo

⭐ *Utilidad*
.help - Mostrar esta lista
`
            await sock.sendMessage(from, { text: helpMessage })
        }

        if (isAdmin && text.startsWith(".ping")) {
            await sock.sendMessage(from, { text: "Estoy activo ✔️" })
        }

        // resaltar
        if (isAdmin && text.startsWith(".resaltar")) {
            const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage

            if (!quoted) {
                return sock.sendMessage(from, {
                    text: "Debes responder al mensaje que quieres resaltar. 📌"
                })
            }

            await sock.sendMessage(from, {
                text: "📌 *Mensaje resaltado por un admin:*",
                quoted: {
                    key: {
                        remoteJid: from,
                        fromMe: false,
                        id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                        participant: msg.message.extendedTextMessage.contextInfo.participant
                    },
                    message: quoted
                }
            })
        }

        // kick
        if (isAdmin && text.startsWith(".kick")) {
            const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid
            if (!mentioned || mentioned.length === 0) {
                return sock.sendMessage(from, { text: "Menciona a un usuario para expulsarlo ❌" })
            }
            await sock.groupParticipantsUpdate(from, mentioned, "remove")
            await sock.sendMessage(from, { text: "👢 Usuario expulsado." })
        }

        // promote
        if (isAdmin && text.startsWith(".promote")) {
            const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid
            if (!mentioned || mentioned.length === 0) {
                return sock.sendMessage(from, { text: "Debes mencionar a quien vas a promover." })
            }
            await sock.groupParticipantsUpdate(from, mentioned, "promote")
            await sock.sendMessage(from, { text: "✅ Usuario ahora es admin." })
        }

        // demote
        if (isAdmin && text.startsWith(".demote")) {
            const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid
            if (!mentioned || mentioned.length === 0) {
                return sock.sendMessage(from, { text: "Debes mencionar a quien vas a degradar." })
            }
            await sock.groupParticipantsUpdate(from, mentioned, "demote")
            await sock.sendMessage(from, { text: "❎ Usuario ya no es admin." })
        }

        // mods - visible to all users
        if (text.startsWith(".mods")) {
            const modList = groupMetadata.participants
                .filter(p => p.admin)
                .map(p => p.id)

            let activos = []
            let inactivos = []

            for (const mod of modList) {
                if (global.modStatus[mod] === "activo") activos.push(mod)
                else inactivos.push(mod)
            }

            let msgText = "👑 *Estado de los MODS*

"

            msgText += "🟢 *Activos:*
"
            msgText += activos.length > 0 
                ? activos.map(id => `• @${id.split("@")[0]}`).join("\n")
                : "No hay mods activos
"

            msgText += "\n\n🔴 *Inactivos:*
"
            msgText += inactivos.length > 0
                ? inactivos.map(id => `• @${id.split("@")[0]}`).join("\n")
                : "Todos están activos o no se han registrado"

            await sock.sendMessage(from, {
                text: msgText,
                mentions: [...activos, ...inactivos]
            })
        }

        // activo
        if (isAdmin && text.startsWith(".activo")) {
            global.modStatus[sender] = "activo"
            await sock.sendMessage(from, {
                text: `🟢 @${sender.split("@")[0]} ahora está *ACTIVO*.`,
                mentions: [sender]
            })
        }

        // inactivo
        if (isAdmin && text.startsWith(".inactivo")) {
            global.modStatus[sender] = "inactivo"
            await sock.sendMessage(from, {
                text: `🔴 @${sender.split("@")[0]} ahora está *INACTIVO*.`,
                mentions: [sender]
            })
        }
    })
}

startBot()